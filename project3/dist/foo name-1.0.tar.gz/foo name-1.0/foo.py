
#A foo module that prints something


def print_something(text):
	print(text)





