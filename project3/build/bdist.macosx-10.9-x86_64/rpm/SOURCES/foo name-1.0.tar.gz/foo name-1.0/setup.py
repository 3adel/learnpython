from distutils.core import setup

setup(name='foo name', version='1.0', py_modules=['foo'], url="http://www.test.com", author="adel", author_email="adel.sh@gmail.com")









	






